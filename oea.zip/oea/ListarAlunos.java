public class ListarAlunos {
    private No inicio;

    // impedir a inserção de dados repetidos
    public boolean existeId(int id) {
        No atual = inicio;
        while (atual != null) {
           // if (atual.aluno.id == id) {
           if(atual.getAluno().getId() == id){
                return true;
            }
            atual = atual.getProximo();
        }
        return false;
    }
    // inserir um novo aluno na lista
    public void inserir(Aluno aluno) {
        if (existeId(aluno.getId())) {
            System.out.println("ID já existe. Não é permitido inserir dados repetidos.");
            return;
        }
        No novoNo = new No(aluno);
        if (inicio == null) {
            inicio = novoNo;
        } else {
            No atual = inicio;
            while (atual!= null) {
                atual = atual.getProximo();
            }
            atual.setProximo(novoNo);
        }
        System.out.println("Aluno inserido: " + aluno);
        
        // listar todos os alunos
        if (inicio == null) {
        System.out.println("lista esta vazia.");
    } else {
        No atual = inicio;
        while (atual != null) {
            System.out.println(atual.getAluno());
            atual = atual.getProximo();
        }
    }
    }

    //pesquisar aluno por id, nome e Telefone
    public void pesquisar(String criterio, String valor) {
        No atual = inicio;
        boolean encontrado = false;
        while (atual != null) {
            if ((criterio.equalsIgnoreCase("id") && String.valueOf(atual.getAluno().getId()).equals(valor)) ||
                (criterio.equalsIgnoreCase("nome") && atual.getAluno().getNome().equalsIgnoreCase(valor)) ||
                (criterio.equalsIgnoreCase("telefone") && atual.getAluno().getTelefone().equals(valor))) {
                System.out.println("Aluno encontrado: " + atual.getAluno());
                encontrado = true;
            }
            atual = atual.getProximo();
        }
        if (!encontrado) {
            System.out.println("Nenhum aluno encontrado com o critério: " + criterio + " e valor: " + valor);
        }
    }
    //Mostrar aluno com uma determinada nota 
    public void listarPorNota(double nota) {
        No atual = inicio;
        boolean encontrado = false;
        while (atual != null) {
            if (atual.getAluno().getNota() == nota) {
                System.out.println("Aluno encontrado: " + atual.getAluno());
                encontrado = true;
            }
            atual = atual.getProximo();
        }
        if (!encontrado) {
            System.out.println("Nenhum aluno encontrado com a nota: " + nota);
        }
    }
}