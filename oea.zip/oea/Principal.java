public class Principal {
    public static void main(String[] args) {
        Aluno a = new Aluno(123, "Gabriel", "9517584", 11);
        System.out.println(a);
    }
    
}
