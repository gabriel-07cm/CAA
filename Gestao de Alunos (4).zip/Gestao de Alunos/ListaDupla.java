
package sistemagestaoalunos;


public class ListaDupla {
    private Listaduplamenteligada inicio;
    private  Listaduplamenteligada fim;

    public ListaDupla() {
        inicio = null;
        fim = null;
    }

    public boolean vazia() {
        return inicio == null;
    }

    public void inserirFim(Aluno aluno) {
        Listaduplamenteligada novo = new Listaduplamenteligada(aluno);

        if (vazia()) {
            inicio = fim = novo;
        } else {
            fim.proximo = novo;
            novo.anterior = fim;
            fim = novo;
        }
    }

    public Aluno removerFim() {
        if (vazia()) {
            return null;
        }

        Aluno aluno = fim.aluno;

        if (inicio == fim) {
            inicio = fim = null;
        } else {
            fim = fim.anterior;
            fim.proximo = null;
        }

        return aluno;
    }

    public Aluno removerInicio() {
        if (vazia()) {
            return null;
        }

        Aluno aluno = inicio.aluno;

        if (inicio == fim) {
            inicio = fim = null;
        } else {
            inicio = inicio.proximo;
            inicio.anterior = null;
        }

        return aluno;
    }

    public void limpar() {
        inicio = null;
        fim = null;
    }
    
}
