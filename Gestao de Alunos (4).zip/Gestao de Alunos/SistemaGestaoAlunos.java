
package sistemagestaoalunos;


public class SistemaGestaoAlunos {

   public static void main(String[] args) {
       
        Aluno a1 = new Aluno(1, "Gabiel", "9597332", 17);
        Aluno a2 = new Aluno(2, "Gelito", "5978071", 16);
        Aluno a3 = new Aluno(3, "Mauro", "9788820", 14);
       

        System.out.println("=== PILHA ===");

        Pilha pilha = new Pilha();

        pilha.push(a1);
        pilha.push(a2);
        pilha.push(a3);

        System.out.println(pilha.pop());
        System.out.println(pilha.pop());

        System.out.println("\n=== FILA ===");

        Fila fila = new Fila();

        fila.inserir(a1);
        fila.inserir(a2);
        fila.inserir(a3);

        System.out.println(fila.remover());
        System.out.println(fila.remover());
        
    }
    
}
