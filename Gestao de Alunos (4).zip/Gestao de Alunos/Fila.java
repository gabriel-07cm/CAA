
package sistemagestaoalunos;


public class Fila {
    private ListaDupla lista = new ListaDupla();

    public void inserir(Aluno aluno) {
        lista.inserirFim(aluno);
    }

    public Aluno remover() {
        return lista.removerInicio();
    }

    public Aluno retirar() {
        return remover();
    }
    
}
