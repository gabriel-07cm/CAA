
package sistemagestaoalunos;


public class Listaduplamenteligada {
    Aluno aluno;
    Listaduplamenteligada anterior;
    Listaduplamenteligada proximo;

    public Listaduplamenteligada(Aluno aluno) {
        this.aluno = aluno;
        this.anterior = null;
        this.proximo = null;
    }
    
}
