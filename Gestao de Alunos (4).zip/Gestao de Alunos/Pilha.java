
package sistemagestaoalunos;


public class Pilha {
    private ListaDupla lista = new ListaDupla();

    public void push(Aluno aluno) {
        lista.inserirFim(aluno);
    }

    public Aluno pop() {
        return lista.removerFim();
    }

    public void limpar() {
        lista.limpar();
    }
    
}
