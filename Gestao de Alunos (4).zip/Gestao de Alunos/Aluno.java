
package sistemagestaoalunos;


public class Aluno {
    private int id;
    private String nome;
    private String telefone;
    private double nota;

    public Aluno(int id, String nome, String telefone, double nota) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.nota = nota;
    }

    @Override
    public String toString() {
        return "ID: " + id +
               ", Nome: " + nome +
               ", Telefone: " + telefone +
               ", Nota: " + nota;
    }
    
}
