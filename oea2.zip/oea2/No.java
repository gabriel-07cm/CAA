public class No {
    private No ant;
    private No prox;
    private Aluno aluno;

    public No(Aluno aluno) {
        this.aluno = aluno;
        this.ant = null;
        this.prox = null;
    }

    public No getAnt() {
        return ant;
    }

    public void setAnt(No ant) {
        this.ant = ant;
    }

    public No getProx() {
        return prox;
    }

    public void setProx(No prox) {
        this.prox = prox;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    
}

