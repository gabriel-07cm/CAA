public class Principal{
    public static void main(String[] args){
        Fila fila = new Fila();
        fila.inserir(new Aluno(2222, "gabriel", "9517584", 13));
        fila.listar();
        Aluno alunoRetirado = fila.retirar();
    }
}