public class Fila{
    private No inicio;
    private No fim;
    public Fila() {
        this.inicio = null;
        this.fim = null;
    }
    
    public void inserir(Aluno aluno){

    }
    
    public Aluno retirar(){
        return new Aluno(0, null, null, 0);
    }
    public void listar(){

    }
}